<?php
class buku{
    public $judulbuku;
    public $pengarang;
    public $penerbit;
    public $tahunterbit;
    public $cetakan;
}
?>